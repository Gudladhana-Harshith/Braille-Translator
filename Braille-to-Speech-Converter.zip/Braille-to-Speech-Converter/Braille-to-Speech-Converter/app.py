import cv2 # Import OpenCV library for image processing
import tempfile # Import temporary file module for creating temporary directory to store uploaded images
import os # Import os module for file management
import uuid # Import uuid module for generating unique ids for uploaded images
from flask import Flask,jsonify,render_template,send_file,redirect,request  #Import Flask library for building web application
from werkzeug.utils import secure_filename # Import secure_filename method from werkzeug.utils module for safely handling uploaded file names
from OBR import SegmentationEngine,BrailleClassifier,BrailleImage  # Import SegmentationEngine, BrailleClassifier, and BrailleImage classes from OBR module
# Define allowed file extensions for image uploads
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
# Create a temporary directory to store uploaded images
tempdir = tempfile.TemporaryDirectory()
# Create a Flask app named "Optical Braille Recognition" and set the upload folder to the temporary directory
app = Flask("Optical Braille Recognition")
app.config['UPLOAD_FOLDER'] = tempdir.name
# Define a function to check if an uploaded file has an allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.' , 1)[1].lower() in ALLOWED_EXTENSIONS
# Route for the home page, which renders the index.html template
@app.route('/')
def index():
    return render_template("index.html")
# Route for the favicon.ico file
@app.route('/favicon.ico')
def fav():
    return send_file('favicon.ico', mimetype='image/ico')
# Route for the cover image (sample1.png) that is displayed on the home page
@app.route('/coverimage')
def cover_image():
    return send_file('samples/sample1.png', mimetype='image/png')
# Route for processed images, which are identified by the img_id parameter
@app.route('/procimage/<string:img_id>')
def proc_image(img_id):
    global tempdir
    print(img_id)
    # Construct the file path for the processed image
    image = '{}/{}-proc.png'.format(tempdir.name, secure_filename(img_id))
    # If the processed image exists and is a file, send it
    if os.path.exists(image) and os.path.isfile(image):
        return send_file(image, mimetype='image/png')
    # If the processed image does not exist, redirect to the cover image
    return redirect('/coverimage')


@app.route('/digest', methods=['POST'])
def upload():
    # check if the post request has the file part
    if 'file' not in request.files:
        return jsonify({"error" : True, "message" : "file not in request"})
    file = request.files['file']
    # if user does not select file, browser also
    # submit an empty part without filename
    if file.filename == '':
        return jsonify({"error": True, "message" : "empty filename"})
    #This line of code checks if the uploaded file has a filename, and if not, returns an error message in JSON format stating that the filename is empty.
    if file and allowed_file(file.filename):
        filename = ''.join(str(uuid.uuid4()).split('-'))
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        #This block of code checks if the uploaded file is valid based on its file extension, and if so, generates a random filename and saves the file in the designated upload folder.
        global tempdir
        
        image_path = '{}/{}'.format(tempdir.name,filename)
        classifier = BrailleClassifier()
        img = BrailleImage(image_path)
        for letter in SegmentationEngine(image=img):
            letter.mark()
            classifier.push(letter)
        cv2.imwrite('{}/{}-proc.png'.format(tempdir.name,filename), img.get_final_image())
        os.unlink(image_path)
        """This block of code initializes a tempdir object, which is used to temporarily store the uploaded file. It then 
        creates a BrailleClassifier object and a BrailleImage object using the uploaded file's path. The SegmentationEngine is
         then used to segment the image into individual Braille letters, which are marked and passed to the classifier. 
         The final processed image is saved in the tempdir folder, and the original image file is deleted."""

    r = {
                "error": False,
                "message": "Processed and Compiled the image successfully",
                "img_id" : filename,
                "digest" : classifier.digest()
        }
    return jsonify(r)

"""This block of code creates a response object in JSON format with information 
about the processed image, including whether there was an error, a success message, the filename of the 
processed image, and the digest of the classifier."""

#@app.route('/speech', methods=['POST'])
#def text_to_speech():
"""These two lines of code are commented out, but suggest that there may be
 additional routes and functions for speech-to-text functionality."""
    

if __name__ == "__main__":
    app.run()
    tempdir.cleanup()
"""This block of code initializes the Flask app and starts the server, 
and also cleans up the temporary directory once the app is stopped."""



