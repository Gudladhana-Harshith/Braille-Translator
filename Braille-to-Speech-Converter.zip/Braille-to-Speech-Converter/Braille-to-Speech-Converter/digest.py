import sys
from OBR import SegmentationEngine,BrailleClassifier,BrailleImage

if len(sys.argv) == 1:
    print("./digest.py [PATH TO SCANNED BRAILLE IMAGE(S)]")
    sys.exit(0)
    #This block of code checks if any arguments were passed to the script.
    # If no arguments were passed, it prints a usage message and exits.



classifier = BrailleClassifier()
#This line of code initializes a BrailleClassifier object,
#which will be used to classify the individual Braille letters in the scanned images.

for path in sys.argv[1:]:
    img = BrailleImage(path)
    for letter in SegmentationEngine(image=img):
        classifier.push(letter)
    print("Digest[{}]: {}\n".format(path, classifier.digest()))
    classifier.clear()
    """This line of code initializes a BrailleClassifier object, which
    will be used to classify the individual Braille letters in the scanned images."""



